from flask import Flask, render_template, jsonify
import requests
import pickle
import numpy as np
import os
import time

app = Flask(__name__)

# ----------------- CONFIGURATION: YOUR THINGSPEAK CHANNEL DETAILS -----------------
THINGSPEAK_CHANNEL_ID = "3131745" 
THINGSPEAK_READ_API_KEY = "854L5KRTYAIBYHWA" 

# Final URL to fetch the latest single entry from your private channel
THINGSPEAK_FETCH_URL = f"https://api.thingspeak.com/channels/{THINGSPEAK_CHANNEL_ID}/feeds.json?api_key={THINGSPEAK_READ_API_KEY}&results=1"

# Load the trained ML model
MODEL_PATH = 'model/fault_classifier.pkl'
try:
    # Ensure the model directory exists before trying to load
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError
        
    with open(MODEL_PATH, 'rb') as file:
        ML_MODEL = pickle.load(file)
    print("✅ ML Model loaded successfully.")
except FileNotFoundError:
    print(f"❌ ERROR: Model file not found at {MODEL_PATH}. You MUST run train_model.py first!")
    ML_MODEL = None
except Exception as e:
    print(f"❌ ERROR loading model: {e}")
    ML_MODEL = None

# In-memory storage for the latest prediction and sensor data
latest_status = {
    'status': 'Awaiting data...',
    'voltage': 0.0, 
    'current': 0.0, 
    'temp': 0.0, 
    'humidity': 0.0,
    'timestamp': 'N/A'
}

# ----------------- ML Prediction & Data Fetch Function -----------------
def get_prediction_from_thingspeak():
    """Fetches the latest data from ThingSpeak and runs the ML model."""
    global latest_status
    
    if ML_MODEL is None:
        latest_status['status'] = "MODEL ERROR"
        return

    try:
        # Fetch data from the configured ThingSpeak URL
        response = requests.get(THINGSPEAK_FETCH_URL, timeout=10)
        response.raise_for_status() # Raises an HTTPError for bad responses (4xx or 5xx)
        data = response.json()
        
        if not data.get('feeds'):
            latest_status['status'] = "NO DATA"
            return
            
        feed = data['feeds'][0]
        
        # ThingSpeak Field Mapping (assuming based on typical setups): 
        # field1=Temp, field2=Hum, field3=Volt, field4=Current
        
        # Safely extract and convert data, defaulting to 0.0 if field is empty or missing
        voltage = float(feed.get('field3') or 0.0) 
        current = float(feed.get('field4') or 0.0)
        temp = float(feed.get('field1') or 0.0)
        humidity = float(feed.get('field2') or 0.0)
        
        # Features for the model: Order MUST be [Voltage, Current, Temp, Humidity]
        features = np.array([[voltage, current, temp, humidity]]) 
        
        # Run Prediction
        prediction = ML_MODEL.predict(features)[0]
        
        # Update status
        latest_status.update({
            'status': prediction,
            'voltage': voltage,
            'current': current,
            'temp': temp,
            'humidity': humidity,
            'timestamp': feed.get('created_at', time.strftime("%Y-%m-%d %H:%M:%S"))
        })

        print(f"Fetched Data: V:{voltage:.2f}, I:{current:.3f}, T:{temp:.1f}, H:{humidity:.1f} | Prediction: {prediction}")
        
    except requests.exceptions.HTTPError as e:
        # Specifically catch 400/403 errors related to API key or channel visibility
        error_code = e.response.status_code
        print(f"ThingSpeak HTTP Error {error_code}: Check Read API Key or Channel ID.")
        latest_status['status'] = f"API FAIL ({error_code})"
    except requests.exceptions.RequestException as e:
        print(f"ThingSpeak Network Error: {e}")
        latest_status['status'] = f"NETWORK FAIL"
    except Exception as e:
        print(f"General Error during prediction: {e}")
        latest_status['status'] = "ML FAIL"


# ----------------- Flask Routes (API & UI) -----------------

@app.route('/')
def dashboard():
    """Serve the main HTML dashboard. Renders from the templates folder."""
    return render_template('dashboard.html')

@app.route('/live_data', methods=['GET'])
def live_data():
    """Endpoint for the UI to poll for the latest ML prediction and sensor data."""
    # This function is called every time the UI polls, ensuring fresh data
    get_prediction_from_thingspeak()
    return jsonify(latest_status)

# ----------------- Main Execution -----------------
if __name__ == '__main__':
    get_prediction_from_thingspeak() # Initial fetch on startup
    
    # Run the server
    print(f"🚀 Starting Flask server. Access UI at http://127.0.0.1:5000/")
    app.run(host='0.0.0.0', port=5000, debug=True, use_reloader=False)
