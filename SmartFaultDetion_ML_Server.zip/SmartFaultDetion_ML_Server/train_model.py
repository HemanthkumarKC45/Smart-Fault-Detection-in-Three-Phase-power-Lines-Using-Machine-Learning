import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import pickle
import os
import numpy as np

# --- 1. Create Sample Training Data Based on Your Sensor Outputs ---
# V=field3, I=field4, T=field1, H=field2.
# Faults are simulated where Voltage (field3) drops to 0.0.

data = {
    # Field 1: Temperature (°C)
    'field1': np.random.uniform(25.0, 30.0, 10).tolist() + [25.5, 26.0, 26.5, 27.0, 27.5, 27.2, 26.8, 25.0, 25.1, 24.9],
    # Field 2: Humidity (%)
    'field2': np.random.uniform(50.0, 60.0, 10).tolist() + [52.0, 53.0, 54.0, 55.0, 56.0, 54.5, 53.5, 52.5, 51.5, 50.5],
    # Field 3: Voltage (V) - Varies between 10-13V for Normal, 0V for Fault
    'field3': [12.0, 11.9, 12.1, 12.0, 11.8, 12.2, 12.3, 11.7, 11.6, 12.4, 
               0.0, 0.0, 0.0, 12.0, 12.1, 0.0, 11.9, 0.0, 12.2, 11.8],
    # Field 4: Current (A) - High current can indicate a short circuit or heavy load
    'field4': [0.10, 0.12, 0.09, 0.11, 0.50, 0.08, 0.07, 0.06, 0.05, 0.04, 
               0.90, 0.95, 0.85, 0.15, 0.02, 0.75, 0.13, 0.80, 0.03, 0.14], 
    
    # Target Labels
    'Fault_Type': ['Normal', 'Normal', 'Normal', 'Normal', 'High_Load_Anomaly', 'Normal', 'Normal', 'Normal', 'Normal', 'Normal', 
                   'Line_Fault', 'Line_Fault', 'Line_Fault', 'Normal', 'Normal', 'Line_Fault', 'Normal', 'Line_Fault', 'Normal', 'Normal']
}

df = pd.DataFrame(data)

# --- 2. Train the Random Forest Model ---
# Features order MUST match the order used in the app.py prediction function!
X = df[['field3', 'field4', 'field1', 'field2']] # Features: Voltage, Current, Temp, Humidity
y = df['Fault_Type']                             # Target: The classification

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X, y)

# --- 3. Save the Model ---
model_dir = 'model'
if not os.path.exists(model_dir):
    os.makedirs(model_dir)

model_path = os.path.join(model_dir, 'fault_classifier.pkl')
with open(model_path, 'wb') as file:
    pickle.dump(model, file)

print(f"✅ Model trained and saved successfully to: {model_path}")
